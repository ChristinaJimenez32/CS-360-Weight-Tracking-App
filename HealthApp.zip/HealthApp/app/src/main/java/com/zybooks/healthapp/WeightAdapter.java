package com.zybooks.healthapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    private List<WeightEntry> weightEntries;
    private OnDeleteClickListener deleteClickListener;
    private OnItemClickListener itemClickListener;

    public interface OnDeleteClickListener {
        void onDeleteClick(WeightEntry weightEntry);
    }

    public interface OnItemClickListener {
        void onItemClick(WeightEntry weightEntry);
    }

    public WeightAdapter(List<WeightEntry> weightEntries, OnDeleteClickListener deleteClickListener, OnItemClickListener itemClickListener) {
        this.weightEntries = weightEntries;
        this.deleteClickListener = deleteClickListener;
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_layout, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        WeightEntry entry = weightEntries.get(position);
        holder.dateTextView.setText(entry.getDate());
        holder.weightTextView.setText(String.valueOf(entry.getWeight()));

        // delete button click
        holder.deleteButton.setOnClickListener(v -> deleteClickListener.onDeleteClick(entry));

        // editing
        holder.itemView.setOnClickListener(v -> itemClickListener.onItemClick(entry));
    }

    @Override
    public int getItemCount() {
        return weightEntries.size();
    }

    // updates data
    public void updateData(List<WeightEntry> newEntries) {
        this.weightEntries = newEntries;
        notifyDataSetChanged();
    }

    // holder for recycler
    public static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView dateTextView, weightTextView;
        Button deleteButton;

        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.textViewDate);
            weightTextView = itemView.findViewById(R.id.textViewWeight);
            deleteButton = itemView.findViewById(R.id.buttonDelete);
        }
    }
}
