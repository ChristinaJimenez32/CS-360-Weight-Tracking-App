package com.zybooks.healthapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "healthapp.db";
    private static final int DATABASE_VERSION = 1;

    // Table for Users
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_GOAL_WEIGHT = "goal_Weight";

    // Table for Weight Entries
    private static final String TABLE_WEIGHT = "weight_entries";
    public static final String COLUMN_ID = "id";
    private static final String COLUMN_USER = "user";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_WEIGHT = "weight";

    // SQL Statements
    private static final String CREATE_USERS_TABLE =
            "CREATE TABLE " + TABLE_USERS + " (" +
                    COLUMN_USERNAME + " TEXT PRIMARY KEY, " +
                    COLUMN_PASSWORD + " TEXT NOT NULL,"+
                    COLUMN_NAME + " TEXT, " +
                    COLUMN_GOAL_WEIGHT + " FLOAT);";

    private static final String CREATE_WEIGHT_TABLE =
            "CREATE TABLE " + TABLE_WEIGHT + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USER + " TEXT NOT NULL, " +
                    COLUMN_DATE + " TEXT NOT NULL, " +
                    COLUMN_WEIGHT + " FLOAT NOT NULL, " +
                    "FOREIGN KEY(" + COLUMN_USER + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USERNAME + "));";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USERS_TABLE);
        db.execSQL(CREATE_WEIGHT_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE " + TABLE_USERS + " ADD COLUMN " + COLUMN_NAME + " TEXT;");
            db.execSQL("ALTER TABLE " + TABLE_USERS + " ADD COLUMN " + COLUMN_GOAL_WEIGHT + " FLOAT;");
        }
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username = ? AND password = ?",
                new String[]{username, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }
    public boolean insertUser(String name, String username, String password, float goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);

        // Insert the new user into the database
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }


    // Updates user info for edit account
    public boolean updateUser(String oldUsername, String newUsername, String newPassword, String newName, double newGoalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        if (newUsername != null && !newUsername.isEmpty()) {
            values.put(COLUMN_USERNAME, newUsername);
        }
        if (newPassword != null && !newPassword.isEmpty()) {
            values.put(COLUMN_PASSWORD, newPassword);
        }
        if (newName != null && !newName.isEmpty()) {
            values.put(COLUMN_NAME, newName);
        }
        if (newGoalWeight >= 0) {
            values.put(COLUMN_GOAL_WEIGHT, newGoalWeight);
        }

        int rows = db.update(TABLE_USERS, values, COLUMN_USERNAME + "=?", new String[]{oldUsername});
        return rows > 0;
    }

    // Method to get user information based on username and displaying it
    public User getUser(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + "=?", new String[]{username});

        if (cursor != null && cursor.moveToFirst()) {

            int nameIndex = cursor.getColumnIndex(COLUMN_NAME);
            int passwordIndex = cursor.getColumnIndex(COLUMN_PASSWORD);
            int goalWeightIndex = cursor.getColumnIndex(COLUMN_GOAL_WEIGHT);

            if (nameIndex == -1 || passwordIndex == -1 || goalWeightIndex == -1) {

                cursor.close();
                return null;
            }

            String name = cursor.getString(nameIndex);
            String password = cursor.getString(passwordIndex);
            double goalWeight = cursor.getDouble(goalWeightIndex);


            // Return the user object
            User user = new User(username, name, password, goalWeight);
            cursor.close();
            return user;
        } else {
            cursor.close();
            return null;
        }
    }



    // Inserting weight entry
    public boolean insertWeight(String user, String date, float weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER, user);
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);

        long result = db.insert(TABLE_WEIGHT, null, values);
        return result != -1;
    }

    // Read weight entries
    public Cursor getWeightEntries(String user) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_WEIGHT + " WHERE " + COLUMN_USER + "=?", new String[]{user});
    }

    // updating the user weight entry
    public boolean updateWeightEntry(int id, float newWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT, newWeight);

        int rows = db.update(TABLE_WEIGHT, values, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    // deleting Weight Entry
    public boolean deleteWeightEntry(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_WEIGHT, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }
    // Method to get the latest weight entry for a user
    public float getLatestWeight(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_WEIGHT + " WHERE " + COLUMN_USER + " = ? ORDER BY " + COLUMN_DATE + " DESC LIMIT 1", new String[]{username});
        if (cursor != null && cursor.moveToFirst()) {
            int weightIndex = cursor.getColumnIndex(COLUMN_WEIGHT);
            float weight = cursor.getFloat(weightIndex);
            cursor.close();
            return weight;
        } else {
            cursor.close();
            return -1;
        }
    }

}

