package com.zybooks.healthapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;

public class EditAccountActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    // EditText Declarations
    EditText nameEditText;
    EditText usernameEditText;
    EditText passwordEditText;
    EditText goalWeightEditText;

    // Button Declarations
    Button updateButton;
    Button cancelButton;

    // Database helper instance
    DatabaseHelper databaseHelper;
    String currentUsername;

    // Drawer elements
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_profile);

        // Retrieve username from Intent
        Intent intent = getIntent();
        currentUsername = intent.getStringExtra("username");

        // Initialize UI components
        nameEditText = findViewById(R.id.nameEditText);
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        goalWeightEditText = findViewById(R.id.goalWeightEditText);

        // Button elements
        updateButton = findViewById(R.id.editAccountButton);
        cancelButton = findViewById(R.id.cancelButton);

        // Initially disable the update button
        updateButton.setEnabled(false);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Load user data from the database
        loadUserData(currentUsername);

        // Text change listener
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateButton.setEnabled(true);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        };

        // Add TextWatcher to each EditText
        nameEditText.addTextChangedListener(textWatcher);
        usernameEditText.addTextChangedListener(textWatcher);
        passwordEditText.addTextChangedListener(textWatcher);
        goalWeightEditText.addTextChangedListener(textWatcher);

        // Button click listener to update user details
        updateButton.setOnClickListener(v -> updateUserDetails());

        // Cancel button click listener to exit the activity
        cancelButton.setOnClickListener(v -> {
            Intent intent1 = new Intent(EditAccountActivity.this, WeightDiaryActivity.class);
            startActivity(intent1);
            finish();
        });

        // Setups DrawerLayout and NavigationView
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(this);

        // Setup Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
    }

    private void loadUserData(String currentUsername) {

        User user = databaseHelper.getUser(currentUsername);
        if (user != null) {
            nameEditText.setText(user.getName());
            usernameEditText.setText(user.getUsername());
            passwordEditText.setText(user.getPassword());
            goalWeightEditText.setText(String.valueOf(user.getGoalWeight()));
        }
    }

    private void updateUserDetails() {
        //updates with new input
        String newName = nameEditText.getText().toString().trim();
        String newUsername = usernameEditText.getText().toString().trim();
        String newPassword = passwordEditText.getText().toString().trim();
        String goalWeightStr = goalWeightEditText.getText().toString().trim();

        double newGoalWeight = -1;
        if (!goalWeightStr.isEmpty()) {
            try {
                newGoalWeight = Double.parseDouble(goalWeightStr);
            } catch (NumberFormatException e) {
                goalWeightEditText.setError("Invalid weight");
                return;
            }
        }

        // Check if no changes were made
        if (newName.isEmpty() && newUsername.isEmpty() && newPassword.isEmpty() && goalWeightStr.isEmpty()) {
            Toast.makeText(this, "No changes detected", Toast.LENGTH_SHORT).show();
            return;
        }

        // Update the user data in the database
        boolean isUpdated = databaseHelper.updateUser(currentUsername, newUsername, newPassword, newName, newGoalWeight);

        if (isUpdated) {
            Toast.makeText(this, "Account updated successfully!", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_weight_diary) {
            // Open Weight Diary Activity
            Intent intent = new Intent(this, WeightDiaryActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_sms_notification) {
            // Open SMS Notification Activity
            Intent intent = new Intent(this, NotificationActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_user_profile) {
            // Already in User Profile
            Toast.makeText(this, "You are already in User Profile", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.nav_logout) {
            // Handle logout
            logoutUser();
        }

        // Closes drawer
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    private void logoutUser() {
        // logout
        getSharedPreferences("user_prefs", MODE_PRIVATE).edit().clear().apply();

        // back to the login screen
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
